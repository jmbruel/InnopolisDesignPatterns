package simucanard.comportements.cancaner.impl;

import simucanard.comportements.cancaner.ComportementCancan;

public class CanardMuet implements ComportementCancan {

	@Override
	public void cancaner() {
		System.out.println("");

	}

}
