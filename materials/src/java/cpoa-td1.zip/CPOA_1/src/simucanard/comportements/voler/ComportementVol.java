package simucanard.comportements.voler;

public interface ComportementVol {
public void voler();

}
