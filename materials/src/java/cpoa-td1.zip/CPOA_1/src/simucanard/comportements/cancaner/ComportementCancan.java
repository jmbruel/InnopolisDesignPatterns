package simucanard.comportements.cancaner;

public interface ComportementCancan {
	public void cancaner();
}
