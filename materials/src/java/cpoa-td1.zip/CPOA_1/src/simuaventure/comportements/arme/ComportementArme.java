package simuaventure.comportements.arme;

public interface ComportementArme {

	public void attaque();
	
	public boolean estOperationnelle();
}