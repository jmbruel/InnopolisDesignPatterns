package simuaventure.comportements.deplacement.impl;

import simuaventure.comportements.deplacement.ComportementDeplacement;

public class ComportementMarcher implements ComportementDeplacement {

	@Override
	public void avancer() {
		// TODO Auto-generated method stub

	}

	@Override
	public void reculer() {
		// TODO Auto-generated method stub

	}

}
