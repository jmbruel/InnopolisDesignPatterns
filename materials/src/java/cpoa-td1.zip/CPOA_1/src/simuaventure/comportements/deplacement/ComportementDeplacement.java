package simuaventure.comportements.deplacement;

public interface ComportementDeplacement {

	public void avancer();
	public void reculer();
}
