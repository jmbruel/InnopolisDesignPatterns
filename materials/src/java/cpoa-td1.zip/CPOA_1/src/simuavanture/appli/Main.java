package simuavanture.appli;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Chevalier ch = new Chevalier();
		Roi artur = new Roi();
		Reine margaux = new Reine();

		ch.avancer();
		ch.frapper();

	}

}
