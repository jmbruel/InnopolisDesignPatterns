package comportement.arme;

public interface ComportementArme {
	void utiliserArme();
}
