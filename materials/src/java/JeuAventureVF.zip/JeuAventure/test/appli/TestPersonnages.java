package appli;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestPersonnages {

	@Test
	public void changementArme() {
		fail("Not yet implemented");
	}

}
